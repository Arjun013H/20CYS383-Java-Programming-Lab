package com.amrita.jpl.cys21010.practice.mathmatical;

public class pattern {
    public  static  void main(String[] args){
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * *  ===================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * *  ===================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * * ====================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * *  ===================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
    }
}
